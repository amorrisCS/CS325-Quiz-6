class OrderDetails:
    def __init__(self, customer_info, items, shipping_address):
        self.customer_info = customer_info
        self.items = items
        self.shipping_address = shipping_address

    def validate_order(self):
        print("Validating order data...")

class OrderCostCalculator:
    def __init__(self, order_details):
        self.order_details = order_details

    def calculate_total_cost(self):
        print("Calculating total order cost...")

class EmailSender:
    def __init__(self, order_details):
        self.order_details = order_details

    def send_confirmation_email(self):
        print("Sending order confirmation email to customer...")

class InventoryUpdater:
    def __init__(self, order_details):
        self.order_details = order_details

    def update_inventory(self):
        print("Updating inventory levels after order processing...")

def main():
    order_info = "Dummy order info"
    items = ["Item1", "Item2"]
    address = "Dummy address"

    order_details = OrderDetails(order_info, items, address)
    order_details.validate_order()

    cost_calculator = OrderCostCalculator(order_details)
    cost_calculator.calculate_total_cost()

    email_sender = EmailSender(order_details)
    email_sender.send_confirmation_email()

    inventory_updater = InventoryUpdater(order_details)
    inventory_updater.update_inventory()

if __name__ == "__main__":
    main()