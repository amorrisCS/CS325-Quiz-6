import logging

class Logger:
    def __init__(self, logger):
        self.logger = logger

    def log(self, message):
        self.logger.info(message)

def main():
    logger = Logger(logging.getLogger())
    logger.log("Dummy log message")

if __name__ == "__main__":
    main()